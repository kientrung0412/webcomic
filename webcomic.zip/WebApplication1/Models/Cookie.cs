﻿using System;
using System.Web;

namespace Model.Models
{
    public class Cookie
    {
        // public HttpCookie SetCookie(string id)
        // {
        //     
        // }
    }
}